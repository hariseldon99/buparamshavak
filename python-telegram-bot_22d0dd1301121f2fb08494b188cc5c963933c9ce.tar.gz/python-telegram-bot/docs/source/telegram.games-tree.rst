Games
-----

.. toctree::
    :titlesonly:

    telegram.callbackgame
    telegram.game
    telegram.gamehighscore
