InputMediaPhoto
===============

.. autoclass:: telegram.InputMediaPhoto
    :members:
    :show-inheritance:
