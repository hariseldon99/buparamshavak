TelegramObject
==============

.. autoclass:: telegram.TelegramObject
    :members:
    :show-inheritance:
    :special-members: __repr__, __getitem__, __eq__, __hash__, __setstate__, __getstate__, __deepcopy__, __setattr__, __delattr__
