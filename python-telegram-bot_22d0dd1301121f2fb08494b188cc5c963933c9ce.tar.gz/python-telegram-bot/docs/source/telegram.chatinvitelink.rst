ChatInviteLink
==============

.. autoclass:: telegram.ChatInviteLink
    :members:
    :show-inheritance:
