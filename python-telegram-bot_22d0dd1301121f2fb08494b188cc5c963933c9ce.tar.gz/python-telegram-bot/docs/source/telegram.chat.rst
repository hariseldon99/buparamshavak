Chat
====

.. autoclass:: telegram.Chat
    :members:
    :show-inheritance:
