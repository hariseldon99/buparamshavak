InputContactMessageContent
==========================

.. autoclass:: telegram.InputContactMessageContent
    :members:
    :show-inheritance:
