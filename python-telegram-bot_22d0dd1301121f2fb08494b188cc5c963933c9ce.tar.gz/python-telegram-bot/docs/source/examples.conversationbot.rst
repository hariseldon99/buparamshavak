``conversationbot.py``
======================

.. literalinclude:: ../../examples/conversationbot.py
   :language: python
   :linenos:

.. _conversationbot-diagram:

State Diagram
-------------

.. mermaid:: ../../examples/conversationbot.mmd
