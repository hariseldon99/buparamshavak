BotCommandScopeAllGroupChats
============================

.. autoclass:: telegram.BotCommandScopeAllGroupChats
    :members:
    :show-inheritance: