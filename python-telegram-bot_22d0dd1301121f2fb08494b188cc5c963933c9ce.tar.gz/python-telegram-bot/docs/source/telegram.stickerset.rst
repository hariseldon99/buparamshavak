StickerSet
==========

.. autoclass:: telegram.StickerSet
    :members:
    :show-inheritance:
