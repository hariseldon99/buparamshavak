``errorhandlerbot.py``
======================

.. literalinclude:: ../../examples/errorhandlerbot.py
   :language: python
   :linenos:
    