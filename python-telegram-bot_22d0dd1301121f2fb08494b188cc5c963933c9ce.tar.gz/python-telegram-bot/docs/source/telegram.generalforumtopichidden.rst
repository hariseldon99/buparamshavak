GeneralForumTopicHidden
=======================

.. autoclass:: telegram.GeneralForumTopicHidden
    :members:
    :show-inheritance:
