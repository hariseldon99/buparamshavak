PersonalDetails
===============

.. autoclass:: telegram.PersonalDetails
    :members:
    :show-inheritance:
