FileCredentials
===============

.. autoclass:: telegram.FileCredentials
    :members:
    :show-inheritance:
