VideoChatStarted
================

.. autoclass:: telegram.VideoChatStarted
    :members:
    :show-inheritance:

