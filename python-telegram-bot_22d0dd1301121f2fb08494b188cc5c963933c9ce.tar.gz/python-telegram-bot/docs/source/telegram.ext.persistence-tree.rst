Persistence
-----------

.. toctree::
    :titlesonly:

    telegram.ext.basepersistence
    telegram.ext.dictpersistence
    telegram.ext.persistenceinput
    telegram.ext.picklepersistence
