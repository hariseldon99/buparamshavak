Video
=====

.. Also lists methods of _BaseThumbedMedium, but not the ones of TelegramObject

.. autoclass:: telegram.Video
    :members:
    :show-inheritance:
    :inherited-members: TelegramObject