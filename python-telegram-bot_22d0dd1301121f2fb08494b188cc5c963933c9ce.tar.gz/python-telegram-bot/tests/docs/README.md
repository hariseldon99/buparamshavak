# Documentation tests

This directory contains tests that cover our scripting logic for automatically generating
additional elements for the documentation pages.

These tests are not meant to be run with the general test suite, so the modules do not have any
`test_` prefix in their names. By default, `pytest` ignores files that have no such prefix.
