#!/bin/bash

rm -Rf ckpt_* dmtcp_restart_* dmtcp_command.* hellompi_[cr].err hellompi_[cr].std
rm -Rf LOGS/*