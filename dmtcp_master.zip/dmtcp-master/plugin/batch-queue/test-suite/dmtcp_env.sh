#!/bin/bash

# DMTCP settings
DMTCP_PATH="/home/research/artpol/sandbox"
export PATH="$DMTCP_PATH/bin/:$PATH"
export LD_LIBRARY_PATH="$DMTCP_PATH/lib:$LD_LIBRARY_PATH"
