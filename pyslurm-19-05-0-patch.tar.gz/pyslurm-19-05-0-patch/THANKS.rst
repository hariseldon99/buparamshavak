Many Thanks to the following :

* Mary Cushion
* Paul Selby
* Andy Bennett
* Moe Jette and Danny Auble for making changes to the SLURM API to avoid clashes with Python reserved words and of course their patience
