#### Details

* Slurm Version:
* Python Version:
* Cython Version:
* PySlurm Branch:
* Linux Distribution:

#### Issue
