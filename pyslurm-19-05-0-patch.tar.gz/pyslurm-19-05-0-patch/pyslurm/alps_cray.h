#ifdef HAVE_ALPS_CRAY
#  define ALPS_CRAY_SYSTEM 1
#else
#  define ALPS_CRAY_SYSTEM 0
#endif
