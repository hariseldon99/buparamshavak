## test_00
---

Run all binaries without the config file.

---
