## test_05
---

Test goslmailer on SLURM versions (<21.8.x) that don't set the job information in as env variables

---
