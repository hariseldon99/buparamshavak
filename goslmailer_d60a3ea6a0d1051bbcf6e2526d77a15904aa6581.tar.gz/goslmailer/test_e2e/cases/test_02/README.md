## test_02
---

goslmailer runs with broken sacct line (-j jobid missing)

---
