## test_01
---

1. run gosler 5 times, save gobs (telegram,toml)
2. run gobler (telegram,toml), trim messages ("maxMsgPU": "3"), render to file and check output

---
